package com.bhanu.pageObjects.organizations;

public class Organizations {

}
