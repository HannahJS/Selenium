package com.bhanu.pageObjects.contacts;

import org.apache.log4j.Logger;

import com.bhanu.helper.logger.LoggerHelper;

public class Contacts {

	private static Logger log = LoggerHelper.getLogger(Contacts.class);
}
